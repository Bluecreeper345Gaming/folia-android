# 汽水音乐（Soda Music / 汽水）登录 + VIP 播放 —— 完整移植说明

本压缩包包含把「汽水音乐」完整接进 Android WebView 应用（Folia 手机版）的全部新增与修改源码，
以及这份足以让另一个 AI 从零复刻出「登录 + 歌单 + 电台 + VIP 播放 + 歌词」的说明。

实现依据是桌面版依赖的 npm 包 `qishui-music-api@0.2.2`（字节跳动车机 Luna 开放平台协议的封装）。
手机版没有 Electron 主进程，因此整套协议在 WebView 的 TypeScript 里重写，HTTP 由 Android 原生
OkHttp 桥（`FoliaBridge`）发出。**协议本身没有改**：常量、参数、签名、请求头都与该包一致。

---

## 0. 交付物清单

```
qishui-port/
├── README.md                                  ← 本文档
├── src/
│   ├── audioNative/
│   │   ├── qishui.ts                          ★新增：整个汽水协议（登录/目录/电台/播放/库）
│   │   ├── core.ts                            修改：FoliaBridge 增加 omitCookies
│   │   └── index.ts                           修改：导出 qishuiRequest
│   ├── services/onlineMusic/
│   │   ├── providerRegistry.ts                修改：注册 qishuiProvider
│   │   └── qishui/                            ★新增整个目录（10 个文件）
│   │       ├── qishuiProvider.ts              平台适配器（能力、auth、catalog、explore…）
│   │       ├── qishuiTransport.ts             渲染进程边界：Electron / Android 原生桥
│   │       ├── qishuiNormalize.ts             实体归一化（歌曲/歌单/用户）
│   │       ├── qishuiPlayback.ts              取单曲、取播放地址、可用性检查
│   │       ├── qishuiCatalog.ts               歌单/最近播放/歌手/喜欢的歌曲
│   │       ├── qishuiExplore.ts               探索页推荐流
│   │       ├── qishuiRecommendations.ts       私人 FM + 场景电台卡片
│   │       ├── qishuiLyrics.ts                KRC/LRC 歌词解析
│   │       ├── qishuiMutations.ts             喜欢/歌单增删
│   │       └── qishuiFailure.ts               错误翻译成共用失败事实
│   ├── utils/lyrics/lyricSources.ts           修改：歌词来源表加 qishui
│   └── i18n/locales/{zh-CN,en,in}.ts          修改：登录文案、歌词来源名、qishui 文案
└── android/app/src/main/java/top/izuna/foliamajor/
    └── FoliaBridgePlugin.java                 修改：request 支持 omitCookies
```

---

## 1. 总体架构

```
渲染进程（WebView）
  src/services/onlineMusic/qishui/qishuiProvider.ts   ← 平台适配器（与其它平台同接口）
        │ requestQishui(operation, params)
        ▼
  qishuiTransport.ts            ← 选择通道：桌面 window.electron.qishuiRequest / 手机原生桥
        │ 手机：await import('../../../audioNative')
        ▼
  src/audioNative/qishui.ts     ← 完整协议实现（本包核心，约 1100 行）
        │ bridgeRequest(...)
        ▼
  FoliaBridgePlugin.java        ← OkHttp；返回 status / headers / body
        ▽
  open.douyin.com / open.qishui.com / open-client.douyin.com / wwwapi…（平台）
```

要点：
- **凭据只存在于渲染进程的会话存储**（localStorage，键 `online_provider:qishui:session`）。
- **所有请求都不带浏览器 Cookie**（`omitCookies: true`）——见第 6 节「坑 1」。
- 账号相关请求用 `bd-ticket-guard` 头（P-256 客户端证书 + ECDSA 签名），公开读取用 `client_token`。

---

## 2. 协议细节（复刻必需）

### 2.1 常量（`protocol.cjs`）

| 名称 | 值 |
| --- | --- |
| UA | `LunaOpenSDK/1.0.10` |
| 平台前缀 | `/api/luna/v1/platform` |
| client_key | `aw4bbxfujo741d09` |
| 公共参数 | `aid=765213 app_id=765213 app_name=byte_autoservice_lite version_code=100010 version_name=1.0.10 channel=bydSong sdk_aid=753999 caller_name=luna_open_sdk sdk_version_code=100000100 sdk_version_name=0.0.1 sdk_channel=Test vehicle_type=BYD device_brand=BYD device_type=BYD device_platform=android resolution=1920x1080 os_version=13 ac=wifi` |
| 设备参数 | `device_id` / `did` / `iid` = 19 位十进制（随机 `8 字节 % 9e18 + 1e18`），`vehicle_id=qishui-<device_id>`，`_timestamp`=秒，`_nonce`=0..65535 |

设备 id 生成与持久化：`src/audioNative/qishui.ts` 的 `createDeviceId()` / `deviceId()`（存 `online_provider:qishui:device_id`）。
必须**固定不变**：它同时出现在查询串和 `ticket` 的绑定里。

### 2.2 两种认证

1. **公开读取（client_token）**
   - `GET https://open.qishui.com/api/luna/v1/platform/client/token/get/?<公共参数>&trigger_type=cold_start`
   - 响应 `data.client_token`（实际值是 `clt.luna.is.number.one`），放进请求头 `access-token`。
   - 进程内缓存；若上游返回 `err_no=28001008`（token 失效），对**只读**接口（search / media/get / playlist detail / mcheck / artist）换一次新 token 重试一次。

2. **账号请求（ticket-guard）**
   - 请求头：
     ```
     access-token: <ticket>
     bd-ticket-guard-version: 1
     bd-ticket-guard-client-cert: <base64(PEM 证书)>
     bd-ticket-guard-client-data: base64(JSON)
     ```
   - `bd-ticket-guard-client-data` 里的 JSON：
     ```json
     {
       "ts_sign": "<登录时服务端下发的 ts_sign>",
       "req_content": "ticket,path,timestamp",
       "req_sign": "<ECDSA-SHA256 的 DER 签名，base64>",
       "timestamp": 1712345678
     }
     ```
   - 签名的原文：`ticket=<ticket>&path=/api/luna/v1/platform<接口路径>&timestamp=<同一秒>`
     （例如 `/me/info/` → `ticket=…&path=/api/luna/v1/platform/me/info/&timestamp=…`）

### 2.3 登录流程（扫码）

| 步 | 请求 | 说明 |
| --- | --- | --- |
| 1 | `GET https://open.douyin.com/oauth/get_qrcode/?<qr 参数>` | 返回 `data.data.token` 与 `data.data.qrcode`（PNG base64）。界面显示 `data:image/png;base64,<qrcode>`。本端生成 32 位 hex 的 `key`，与 token 一起存内存 5 分钟。 |
| 2 | 每 2 秒 `GET https://open.douyin.com/oauth/check_qrcode/?<qr 参数>&token=<token>&timestamp=<ms>` | `status` ∈ `new/scanned/confirmed/expired/refused`。`new→waiting`，`scanned→scanned`，`refused→error`，`confirmed` 取 `data.code`（或 `auth_code`）。 |
| 3 | `GET https://open.qishui.com/api/luna/v1/platform/access/code/get/?<公共参数>&auth_code=<code>` | 换 `access_code`（`data.data` 或 `data`）。 |
| 4 | `POST https://open-client.douyin.com/passport/open/get_access_ticket/?aid=1128&client_key=aw4bbxfujo741d09&device_platform=android`，表单体 `access_code=…&open_id=…`，头 `bd-ticket-guard-version: 1` + `bd-ticket-guard-client-csr: <base64(PEM CSR)>` | 响应头 **`bd-ticket-guard-server-data`** = base64(JSON)，内含 `ticket`、`ts_sign`、`client_cert`。 |
| 5 | `POST /api/luna/v1/platform/me/info/`（带 ticket-guard 头） | 响应 `data.my_info`：`id`、`nickname`、`medium_avatar_url/avatar_url`、**`is_vip`**（VIP 状态）。 |

`qr 参数`（登录二维码专用）：
```
aid=1128 client_key=aw4bbxfujo741d09
scope=user_info,luna.openapi.platform.interaction,luna.openapi.platform.me_tab,luna.commerce.openapi_platform.vip_info
state= next= jump_type=native optional_scope_check= optional_scope_uncheck=
customize_params={"source":"pc_auth","not_skip_confirm":"true"}
source_from=native device_platform=android
app_identity=md5("com.luna.music.car")   // 运行时算，不要写死
signature=cf9024ea72d9c71813238b13ea107a3d
```
**scope 里必须包含 `luna.commerce.openapi_platform.vip_info`**，否则拿不到会员状态。

### 2.4 ticket-guard 密码学（最容易写错的地方）

需要：
1. 现场生成 **P-256 (prime256v1) EC 密钥对**。
2. 用它生成 **PKCS#10 CSR**（DER），提交给第 4 步；PEM 后 **base64 整个 PEM 文本**放进 `bd-ticket-guard-client-csr`。
3. 后续所有账号请求用同一私钥签名。

CSR 的 DER 结构与 `qishui-music-api/src/protocol.cjs` 完全一致：

```
CertificationRequest ::= SEQUENCE {
  certificationRequestInfo SEQUENCE {
    version            INTEGER 0,
    subject            SEQUENCE {            -- 3 个 SET
      SET { SEQUENCE { OID 2.5.4.3  (CN), UTF8String "bd-ticket-guard" } },
      SET { SEQUENCE { OID 2.5.4.11 (OU), UTF8String "" } },
      SET { SEQUENCE { OID 2.5.4.10 (O),  UTF8String "" } }
    },
    subjectPKInfo      SPKI DER (P-256 公钥),
    attributes         [0] { }               -- 空
  },
  signatureAlgorithm   SEQUENCE { OID 1.2.840.10045.4.3.2 }   -- ecdsa-with-SHA256
  signature            BIT STRING { 0 unused bits, DER(ECDSA 签名) }
}
```

实现细节（`src/audioNative/qishui.ts` 里 `der()` / `derInteger()` / `createGuard()` / `signDer()`）：
- WebCrypto `crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'}, key, data)` 返回的是 **r‖s 裸签名**（64 字节），
  而 Node 的 `crypto.sign` 返回 **DER**。必须转换成 DER：
  `r、s 各 32 字节 → 去前导零 → 最高位 ≥0x80 前面补 0x00 → SEQ(INTEGER(r), INTEGER(s))`。
- 公钥用 `exportKey('spki')` 得到 DER；私钥用 `exportKey('pkcs8')` 存 base64，之后 `importKey('pkcs8', …)` 复用。
- 服务端返回的 `client_cert` 若含 `-----BEGIN`，要 **base64(UTF-8(PEM))** 后才放进请求头。
- 已用 Node 的 `crypto.verify` 验证过：本实现产出的 DER 签名可被标准 P-256 公钥验证，CSR 结构
  （info 149 字节、整包 238 字节）与 `node:crypto` 生成的一致。

### 2.5 会话与刷新

会话对象（存 `online_provider:qishui:session`，JSON）：
```ts
{
  deviceId, guardKey /* base64 PKCS8 */, ticket, guardCert, guardTsSign,
  accessCode, openId, expiresAt /* ms */, userId, user: { id, nickname, avatar, isVip }
}
```
`login_status`（启动时、账号页刷新时）：
1. 读会话；没有 → 返回 null（未登录）。
2. 若 `expiresAt < now + 1h`：`GET /access/code/refresh/?<公共参数>&access_code=<旧>` →
   重新走第 4 步换 ticket（头里用旧的 `bd-ticket-guard-client-cert`），`expiresAt` 取 `access.expires_time`。
3. `POST /me/info/` 读账号（顺带更新 `is_vip`）。
4. 账号 id 变了 → 清会话并报 `auth-required`。
5. `auth-required` **且带上游错误码** → 视为账号被平台拒绝，清会话。

### 2.6 目录 / 媒体 / 账号接口（全部 POST，body 带 `common_params`）

> 请求头：公开读 `access-token: client_token`；账号读 `ticket-guard` 全套 + `access-token: ticket`。
> body 形如 `{ …业务参数…, common_params: { user_id: "<当前账号 id，未登录省略>" } }`
> 登录后即使走公开 token，也要带 `common_params.user_id`：平台靠它判定会员权益，**这是 VIP 能播的关键之一**。

| 用途 | 路径 | 关键参数 |
| --- | --- | --- |
| 搜索 | `/search/` | `q, cursor, search_id, from_search_id, search_method:"input", search_type:"track"/"playlist", search_scene:"normal", scene_name:"search", ab_param:"", last_viewed_media:{}`；结果在 `data.result_groups` 里找 `id=="tracks"`/`"playlists"` |
| 单曲 | `/media/mget/` | `media_list:[{id,type:"track"}], card_context:{}` → `media_list[].track_entity` |
| 批量可用性 | `/media/mcheck/` | `media_list:[{id,type:"track"}]` → `media_status_list[].risk_info.risk_result`（0 可播；非 0 未知） |
| 歌单详情/歌曲 | `/playlist/detail/` | `playlist_id, owner_id, count:100, cursor:"0", type:null` → `media_entities`、`next_cursor`、`has_more`、`playlist` |
| 我的歌单 | `/me/playlist/` | `count:100, cursor:"", item_types:["playlist"]` → `playlists` / `playlist_list`（**必须账号凭据**） |
| 收藏合集 | `/me/collection/mixed/` | 同上 → `mixed_collections` |
| 最近播放 | `/me/recent-played/` | `count:100, cursor, media_type:"track", scene:"me_tab"` → `media[].media.track_entity`（账号凭据） |
| 歌手 | `/artist/detail/`、`/artist/tracks/` | `artist_id` |
| 喜欢列表 | `/me/playlist/` 找 `base_info.type==1` 的歌单，再 `/playlist/detail/` 全量翻页 | 得到 id 集合 |
| 喜欢/取消 | `/media/collect/`、`/media/cancel/collect/` | `media:[{id,type:"track"}], scene:"", collect_action:1`（账号写，用 command） |
| 歌单加/删歌 | `/playlist/append/`、`/playlist/delete/` | `playlist_id, media:[…]`（账号写） |
| 不喜欢 | `/dislike/` | `item_id, author_ids:[], dislike_item_type:"track", action_type: 0/1`（账号写） |
| 歌词 | `/media/mget/` | 取 `track.display_info.lyric_info` |

### 2.7 电台（feed）

| 用途 | 路径 | 参数 |
| --- | --- | --- |
| 场景表 | `/feed/mode/` | 无业务参数 → `data.feed_mode_block[].feed_mode[].entity.feed_mode`，取 `scene_mode.scene_mode_id`、`text`、`url_info` |
| 推荐流 | `/feed/song-tab/` | 见下 |

`/feed/song-tab/` body：
```json
{
  "played_media": [],
  "is_first_request": <state.count === 0>,
  "with_client_cache": <state.count !== 0>,
  "is_did_first_request": false,
  "count": 20,
  "feed_preference": {
    "scene_mode_id": <场景 id 或 null>,
    "scene_mode_select_time": <选中场景的时间戳 或 null>,
    "preference_mode": "familiar" | "fresh" | null,
    "total_request_count": <自增>,
    "preference_mode_request_count": <state.count+1>,
    "current_mode_request_count": <state.count+1>
  }
}
```
- 队列 key = `queue:scene|preference|default`，同一队列的请求**串行**（本实现用 promise 链），避免两页互相消费对方的光标。
- 返回 `data.items[]`（过滤掉 `type` 非 `track` 的卡片）与 `data.has_more`。
- 探索页用 `queue="explore"`；私人 FM 用 `queue="fm"`（可带 `scene` 或 `preference`）。

### 2.8 播放取链（`playback.cjs`）

1. `/media/mget/` 拿 `track_entity.player_info`。
2. 依次尝试 `player_info.full`、`player_info.preview` 两档；每档：
   - 若 `video_model_info.video_model` 存在：解析（可能是字符串 JSON），遍历 `video_list`，
     **跳过加密项**（`encrypt_info.encrypt` / `encrypt_info.spade_a` / `PlayAuth` / `Encrypt` 非 0），
     取 `main_url` + `video_meta.quality/bitrate`。
   - 否则若 `video_model_info.url_player_info` 存在：**再请求该地址**，取
     `data.Result.Data.PlayInfoList` / `data.data.PlayInfoList` / `data.PlayInfoList`，
     同样跳过加密项，取 `MainPlayUrl` + `Quality` / `Bitrate`。
3. 域名白名单（https、无端口、无 userinfo）：
   `365yg.com / douyinvod.com / douyinscdn.com / bytefcdn.com / bytecdn.cn / byteicdn.com / ibytedtos.com / pstatp.com / snssdk.com / bytedance.com / bytetos.com / volcvideo.com / volccdn.com / volces.com / volcengineapi.com / douyin.com / qishui.com / zijieapi.com / zjcdn.com`
   （含子域）。不在白名单的候选丢弃并记日志，不会返回不可信地址。
4. 质量映射：`medium→standard, higher→high, highest→high, lossless→lossless, hi_res→hires`；
   在不超过所需质量里挑最高，其次码率最高。
5. 返回 `{ url, quality, fetchedAt, expiresAt?, preview }`；`preview=true` 表示只是试听片段。
6. 两档都只有加密音频 → 抛 `unsupported: "Qishui returned protected audio only; decryption is disabled"`
   **不实现解密**（与桌面端一致）。

> VIP 判定并不在取链这一步「解锁」：平台根据 `common_params.user_id` 的会员状态决定
> `player_info` 是否给出明文完整音频。因此**登录会话与 user_id 必须正确传入每一个请求**。

### 2.9 错误码

`checked()` 把 `err_no`（或 `data.error_code`）非 0 视为错误：
- `28001003 / 28001007 / 28001008 / 10007` → `auth-required`
- 其它 → `unavailable`（带上游码字符串）
- HTTP 401/403 → `auth-required`；429 → `unavailable`；其余非 2xx → `network`

**不要吞掉 `28001007`**：它表示「需要登录态」，未登录时应显示登录提示，而不是重试。

### 2.10 歌词

`lyric_info.lyric_entity` 的 `content` + `type`（`krc`/`lrc`）。译文在 `lyric_info.lang_translations`
（优先 `zh-CN` / `ZH-HANS-CN`，否则取第一个），按**行起始时间**对齐到主歌词。逐字歌词即 `type==='krc'` 的原文。

---

## 3. 逐文件说明

### 3.1 `src/audioNative/qishui.ts`（★新增，核心）

职责：把 `qishui-music-api@0.2.2` 的 `protocol / client / auth / catalog / library / playback / feed / api`
全部搬到 WebView。对外只导出一个函数：

```ts
export const qishuiRequest = async (operation: string, raw: Record<string, any> = {}): Promise<any>
```

支持的 operation：
`login_qr_key / login_qr_create / login_qr_check / login_qr_cancel / login_status / logout /
search / search_playlists / song_detail / audio / lyrics /
user_playlists / playlist_detail / playlist_tracks / artist_detail / artist_songs /
liked_songs / like_song / playlist_add_tracks / playlist_remove_tracks /
recent_played / check_tracks / dislike_song / feed / feed_modes`

内部结构（按出现顺序，便于对照阅读）：

| 区块 | 关键符号 | 作用 |
| --- | --- | --- |
| 错误 | `QishuiError` | `code / upstreamCode / stage / cause` |
| 常量 | `UA/PREFIX/CLIENT_KEY/COMMON` | 见 2.1 |
| 设备 | `createDeviceId / deviceId` | 19 位持久 id |
| 密码学 | `utf8/concat/derLength/der/derInteger/hexBytes/base64/fromBase64/signDer/createGuard/guardHeaders/readGuard/credentialExpiry` | 见 2.4 |
| 会话 | `readSession/writeSession/clearSession` + 模块级 `cachedSession` | localStorage JSON |
| HTTP | `checked/http/query/headerReader` | 经 `bridgeRequest`，`omitCookies:true`、`followRedirects:false`、25s |
| 公开 token | `clientToken/RETRYABLE_READS` | 缓存 + 28001008 单次重试 |
| 账号请求 | `platform(path, body, credential?)` / `command(path, body)` | 见 2.6 |
| 目录 | `publicTrack/trackById/search/playlistPage` | 见 2.6 |
| 库 | `likedPlaylist/likedSongs/recentPlayed/checkTracks/userPlaylists` | 见 2.6 |
| 电台 | `clearQishuiFeed/feedModes/feedSongs` | 见 2.7，含串行队列 |
| 播放 | `MEDIA_HOSTS/mediaUrl/LEVELS/RANK/isEncrypted/resolveAudio` | 见 2.8 |
| 登录 | `qrParams/createGuard 使用/pending/loginStatus/renew` | 见 2.3/2.5 |
| 分发 | `qishuiRequest` 的 `switch` | 每个 operation 校验参数后调用上面的实现 |

**必须保留的日志**（排查期非常有用，且不含 token）：
- `[Qishui] status: stored session found { expiresInMin, needsRefresh }`
- `[Qishui] status: account read failed { code, upstreamCode, stage, message }`
- `[Qishui] Sign-in QR created`
- `[Qishui] Sign-in confirmed; account stored { vip }`
- `[Qishui] Plaintext audio issued: quality=… preview=…`
- `[Qishui] Skipped untrusted media hosts: …`

### 3.2 `src/audioNative/core.ts`（修改）

`FoliaBridgeRequestOptions` 增加：

```ts
/** true 时不附加 CookieManager 的会话 Cookie，也不写入响应的 Set-Cookie */
omitCookies?: boolean;
```

### 3.3 `src/audioNative/index.ts`（修改）

在文件中部（`extensionBodianRequest` 之后）增加：

```ts
/** 汽水音乐：整个车机 Luna 协议在 WebView 内跑（桌面版在 Electron 主进程）。 */
export { qishuiRequest } from './qishui';
```

### 3.4 `src/services/onlineMusic/qishui/qishuiTransport.ts`（★新增）

- 定义 operation 联合类型与 `QishuiParams`。
- `QishuiRequestError`：`OnlineProviderError` 子类，带 `stage`（`access-code|ticket|account`）与 `upstreamCode`。
- `getQishuiAvailability()`：桌面有 `window.electron.qishuiRequest` 或手机原生桥 → `configured:true`。
- `requestQishui()`：优先 Electron；否则 `await import('../../../audioNative')` 调 `qishuiRequest`；
  把原生错误按 `code` 映射成 `OnlineProviderError`，登录类操作记录 `lastFailure` 供诊断。

### 3.5 `src/services/onlineMusic/qishui/qishuiProvider.ts`（★新增）

```ts
export const qishuiProvider: OnlineMusicProvider = {
  id: 'qishui', displayName: '汽水音乐', shortName: '汽水',
  mark: { letter: '汽', color: '#19a58c' },
  getAvailability: getQishuiAvailability,
  capabilities: { search, playback, lyrics, wordByWordLyrics, auth, userLibrary, playlists,
                  albums:false, artists, recommendations:true, explore:true, mutations, likes,
                  playlistTrackMutations },
  normalizeSong / normalizeUser / normalizeCollection,
  songMetadata: { getSongMetadata: createProviderSongMetadata },
  describeFailure: describeQishuiFailure,
  getSongPageUrl: song => `https://music.douyin.com/qishui/share/track?track_id=…`,
  search: { searchSongs }, playback: qishuiPlayback,
  lyrics: { getLyrics: … },
  auth: {
    getLoginTexts: () => ({ title: 'home.loginTitleQishui', note: 'home.loginNoteQishui' }),
    getLoginStatus,            // login_status，auth-required → null（这是「没登录」而不是错误）
    startLogin,                // login_qr_key → key
    createQr,                  // login_qr_create → imageUrl
    checkLogin,                // login_qr_check；network 失败 → { state:'error', transient:true }
    cancelLogin,               // login_qr_cancel
    getLoginTtlMs: 5 分钟,      // 与二维码有效期一致
    logout, signInRanOut: clearAccountState, describeLoginFailure, getLoginDiagnostics
  },
  catalog: qishuiCatalog, library: qishuiLibrary,
  explore: qishuiExplore, recommendations: qishuiRecommendations,
  mutations: qishuiMutations,
}
```

`clearAccountState()`：清空播放可用性缓存、探索流、场景表缓存（登录/退出/过期时调用）。

### 3.6 `qishuiNormalize.ts`（★新增）

- `normalizeQishuiSong`：`base_info.id/name/duration_ms`、`related_info.artist_links`、`album_link`、
  `display_info.cover_url`；**id 保持字符串**（19 位整数超出 JS 安全整数）。
- `normalizeQishuiCollection`：`base_info.type==1` 且 `isOwned` → `isLiked:true`；
  `providerData.ownerId` 留给后续翻页。
- `normalizeQishuiUser`：`isVip → vipType: 1`。
- `qishuiImage`：封面对象可能是 `{urls:[…], uri, template_prefix}`，需要拼
  `urls[0] + uri + "~<template_prefix>-image.image"`。

### 3.7 `qishuiPlayback.ts`（★新增）

- `readQishuiSongs(raw[])`：归一化后批量 `check_tracks`，把 `risk_result` 记成 60 秒可用性缓存
  （失败只 warn，绝不影响歌曲列表）。
- `getSongDetail`：`not-playable + "Qishui did not return the track"` → `null`（歌不存在，不是请求失败）。
- `getAudioSource`：`audio { id, quality }`。
- `audioQualityLevels`：`['standard','high','lossless','hires']`。

### 3.8 `qishuiCatalog.ts`（★新增）

- `getPlaylistTracks`：`recent-played` 走 `recent_played`；`scene:<id>` 走 `feed`（场景电台流）；
  其余走 `playlist_tracks`。
- `getPlaylistDetail`：`recent-played` 返回本地构造的「最近播放」；`scene:<id>` 用场景表补名字/分组。
- `getArtistSongs/getArtistDetail`。
- `qishuiLibrary.getUserPlaylists`：把 offset 0 让给本地「最近播放」卡，其余行来自 `user_playlists`。
- `getLikedSongIds`：`liked_songs`，要求 `ids` 全为数字串且 `whole` 是布尔。

### 3.9 `qishuiExplore.ts`（★新增）

- 每次从头读（`read` 计数），一次 20 首；同一轮里跨批去重（`shown`）。
- `moreCursor = "qishui:<read>:<batch>"`，最多 10 批；`getSectionItems` 校验 read 代次，
  旧轮的 cursor 一律返回空（这是 Explore 适配器的约定）。
- 标题用 `i18n.t('qishui.recommended')`。

### 3.10 `qishuiRecommendations.ts`（★新增）

- `readScenes()`：`feed_modes`，10 分钟缓存；过滤非数字 id / 空名 / 重复。
- `getRecommendedCollections(limit)`：场景 → `type:'radio'` 集合，id `scene:<sceneId>`，
  描述为分组名，封面 `qishuiImage(url_info)`。
- `getPersonalFm(options)`：`feed { queue:'fm', limit:20, scene/preference 按 mode }`。

### 3.11 `qishuiLyrics.ts`（★新增）

`lyric_info` → `parseLyricsByFormat(krc|lrc)`；译文按行 `startTime` 对齐；返回
`wordByWordText`（krc 原文）与 `translationText`。

### 3.12 `qishuiMutations.ts`（★新增）

- `qishuiSongId(song)`：从 `sourceRef` 取 `mediaId`，不属于汽水则 `unsupported`。
- `editable(collection)`：`providerId==='qishui' && type==='playlist' && isOwned && !isLiked`。
- `likeSong` / `updatePlaylistTracks`（`'add'` / 其它都按 remove；最多 100 首）。

### 3.13 `qishuiFailure.ts`（★新增）

把错误翻译成共用事实：`not-configured / local-service-stopped / signedOut / no-audio / httpStatus / code`。
注意「Sign in to Qishui first」要映射成 `signedOut`，而不是「登录过期」。

### 3.14 `src/services/onlineMusic/providerRegistry.ts`（修改）

```ts
import { qishuiProvider } from './qishui/qishuiProvider';
…
registerOnlineMusicProvider(qishuiProvider);
```

### 3.15 `src/utils/lyrics/lyricSources.ts`（修改）

```ts
{ id: 'qishui', labelKey: 'lyricProvider.qishui', platform: true },
```

### 3.16 `src/i18n/locales/zh-CN.ts / en.ts / in.ts`（修改）

新增键（`zh-CN` 为基准，其它语言缺键会自动回落到中文）：

```ts
home.loginTitleQishui: "使用抖音/汽水音乐APP扫码"
home.loginNoteQishui:  "用抖音或汽水音乐 App 扫描二维码并确认授权（含会员信息）"
lyricProvider.qishui:  "汽水音乐"
qishui.recentPlayed:   "最近播放"
qishui.recommended:    "为你推荐"
```

### 3.17 `android/…/FoliaBridgePlugin.java`（修改）

1. `request()` 读取 `omitCookies`：
```java
boolean omitCookies = Boolean.TRUE.equals(call.getBoolean("omitCookies"));
call.resolve(executeWithRedirects(…, followRedirects, omitCookies));
```
2. `executeWithRedirects(...)` 增加参数，并：
   - 不附加 CookieManager 的 Cookie：`if (!omitCookies && 没有显式 Cookie 头) { … }`
   - 不写回 `Set-Cookie`：`if (!omitCookies) { for (String setCookie : response.headers("Set-Cookie")) … }`

**这是必须的**：不关掉 Cookie 时，同一域上二维码登录留下的 Cookie 会让网关走另一条路径，
`/feed/mode/` 等请求会一直拖到 25 秒超时（实测 31 秒后才失败）。桌面版桥接本来就 `credentials:'omit'`。

---

## 4. 接入一个已有播放器的步骤（复刻清单）

1. **HTTP 桥**：实现一个「发请求、拿 status/headers/body」的函数，并支持**不发 Cookie**。
   没有原生桥时可用 `fetch(url,{credentials:'omit',redirect:'error'})`（浏览器会被 CORS 拦，需代理）。
2. **会话存储**：`online_provider:qishui:device_id`、`online_provider:qishui:session`（JSON）。
3. **搬入 `src/audioNative/qishui.ts`**，把 `bridgeRequest` 指向第 1 步的桥。
4. **搬入 `src/services/onlineMusic/qishui/*`**，实现你播放器的 provider 接口
   （最小集：`getLoginStatus/startLogin/createQr/checkLogin/cancelLogin/logout`、
   `searchSongs`、`getSongDetail`、`getAudioSource`、`getLyrics`、`getUserPlaylists`、`getLikedSongIds`、
   `getPlaylistTracks`、`getRecommendedCollections`、`getPersonalFm`）。
5. **注册 provider**，加 `capabilities`：`search/playback/lyrics/auth/userLibrary/playlists/artists/
   recommendations/explore/mutations/likes/wordByWordLyrics`。
6. **登录 UI**：二维码流程只要 4 个方法（见 3.5）。二维码有效期 5 分钟、轮询间隔 2 秒；
   扫过但 60 秒不确认按超时处理。
7. **播放器**：直接把 `getAudioSource().url` 交给 `<audio>`/ExoPlayer；若是 `preview:true`，
   标记为试听片段（不要缓存成整首）。
8. **验收**：登录后启动应用应能看到「4 个歌单 / 喜欢 N 首」；电台页出现多张场景卡；
   播 VIP 歌应出现 `[Qishui] Plaintext audio issued … preview=false`。

---

## 5. 会话持久化（重启不掉登录）

- 会话写 `localStorage`（origin 固定，如 `https://localhost`），**不要**只在内存里保存。
- 启动时 `getLoginStatus` → `login_status` → 读会话 → `/me/info/`。
- 关键点：**账号读取的第二次请求（`/me/playlist/` 等）失败也会被上层当作「账号读不到」，
  看起来就像被退登**。因此凡是「账号读取链」会用到的接口都必须实现（`user_playlists` 就是之前缺的）。
- `auth-required` 不带上游码时保持会话（可能只是暂时 401），只在**带上游码**时清会话。

---

## 6. 两个必踩的坑

**坑 1：请求带 Cookie → 25 秒超时**
现象：`[Omni] Home feed section failed`，且对应请求 31 秒后才失败；`/feed/mode/` 无响应。
原因：二维码登录后 CookieManager 在 `open.douyin.com` 上留下了会话 Cookie，桥默认会带上。
解决：汽水的每个请求都 `omitCookies: true`（Java 与 TS 两端都改）。

**坑 2：WebCrypto 签名是裸 r‖s，不是 DER**
现象：`get_access_ticket` 或 `/me/info/` 返回 401/签名错误。
解决：`signDer()` 按第 2.4 节转 DER；生成 CSR 时公钥用 `exportKey('spki')`。

---

## 7. 日志速查

| 日志 | 含义 |
| --- | --- |
| `[Qishui] status: stored session found {expiresInMin, needsRefresh}` | 启动时读到会话 |
| `[Qishui] status: no stored session` | 本地没有会话（正常未登录） |
| `[Qishui] status: account read failed {code, upstreamCode, stage}` | 会话在但读账号失败（401/网络） |
| `[Qishui] Sign-in QR created` / `Sign-in confirmed; account stored {vip}` | 登录两阶段成功，`vip` 即会员状态 |
| `[Qishui] Liked songs read {count, whole}` | 喜欢列表读全 |
| `[Qishui] Plaintext audio issued: quality=… preview=…` | 取到明文地址；`preview=false` 为整首 |
| `[Qishui] Track availability check failed {code}` | `/media/mcheck/` 被拒（不影响播放） |
| `[Qishui] Skipped untrusted media hosts: …` | 地址不在白名单，已丢弃 |

---

## 8. 已知限制（与桌面版一致）

1. **不解密**：`player_info` 只有加密音频时抛 `protected audio only`，不做 CENC/密钥提取。
2. `/media/mcheck/` 在当前环境可能固定回错（`Qishui rejected the request`），可用性只当参考，不影响播放。
3. 专辑接口不存在（车机协议没有），`capabilities.albums=false`。
4. 场景电台没有 `personalFm` 字段可依赖时，点击场景卡按「取一批歌」处理；继续加载就是再取一批新歌。
5. 会员状态只在登录/刷新账号时读取（`user.is_vip`），平台侧据此决定是否给完整音频。
